package com.cts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.exception.CtsBankException;
import com.cts.repository.CustomerRepository;

@Service(value = "customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Integer updateCityOfCustomer(Integer customerId, String city)
			throws CtsBankException {
		return customerRepository.updateCityOfCustomer(customerId, city);
	}

	@Override
	public Integer deleteCustomer() throws CtsBankException {
		return customerRepository.deleteCustomer();
	}

}
