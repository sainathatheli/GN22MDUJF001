package com.cts.service;

import com.cts.exception.CtsBankException;

public interface CustomerService {

	Integer updateCityOfCustomer(Integer customerId, String city) throws CtsBankException;

	Integer deleteCustomer() throws CtsBankException;

}
