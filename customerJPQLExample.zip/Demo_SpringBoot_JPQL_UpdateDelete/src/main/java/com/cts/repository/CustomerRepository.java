package com.cts.repository;

public interface CustomerRepository {

	public Integer updateCityOfCustomer(Integer customerId, String city);

	public Integer deleteCustomer();
	
}
